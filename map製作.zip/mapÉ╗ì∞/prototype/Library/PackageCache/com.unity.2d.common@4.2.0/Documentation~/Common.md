2D Common

# Overview

This package contains shared code used by various 2D projects such as SpriteShape, Animation etc..